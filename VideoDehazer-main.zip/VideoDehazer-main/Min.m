function [m]=Min(I)
m=min(I(:));
end