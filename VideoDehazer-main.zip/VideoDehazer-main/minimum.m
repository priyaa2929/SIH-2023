function [m]=minimum(I)
m=min(I(:));
end
